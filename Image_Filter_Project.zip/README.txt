﻿Image Filter  Website’s Urls:


1. Elastic beanstalk url.
http://image-filter-tony-dev-dev.us-east-1.elasticbeanstalk.com


2. Git Repository url:
https://github.com/void-fx/Image_Filter.git